source("VSM_main_function.R")
source("detailed_calculate.R")
source("ridge_GIC.R")
source("Ite_Est_ridge.R")

library(MASS)
library(glmnet)
library(lqa)
library(parcor)
library(locfit)

### START tuning parameter ###
monte_num <- 1 # the number of simulations
n_sample <- 200  # sample size
true_stan_dev <- sqrt(0.025) # standard deviation of errors

basis_num_vec = 40
width_para = 10^(-3)

start_smooth <- 10^(-9)
end_smooth <- 10^(-1)
n_smooth <- 5

start_gamma_1 <- exp(-6)
end_gamma_1 <- exp(-4)
start_gamma_2 <- exp(-6)
end_gamma_2 <- exp(-4)
n_gamma <- 3		
### END tuning parameter ###

######
true_func_num <- 1
start_data=0
end_data=1

result_VSM <- VSM_main_function(monte_num, n_sample, start_data, end_data, true_stan_dev
                                , true_function, basis_num_vec, width_para, start_smooth, end_smooth
                                , n_smooth, n_gamma, start_gamma_1, end_gamma_1, start_gamma_2, end_gamma_2)

MSE_VSM <- result_VSM[[1]]
MSE_ridge <- result_VSM[[2]]
MSE_lasso <- result_VSM[[3]]
MSE_adalasso <- result_VSM[[4]]
MSE_locfit <- result_VSM[[5]]

mean_MSE_ridge <- mean(MSE_ridge)
mean_MSE_lasso <- mean(MSE_lasso)
mean_MSE_adalasso <- mean(MSE_adalasso)
mean_MSE_VSM <- mean(MSE_VSM)
mean_MSE_locfit <- mean(MSE_locfit)

SD_MSE_ridge <- sd(MSE_ridge)
SD_MSE_lasso <- sd(MSE_lasso)
SD_MSE_adalasso <- sd(MSE_adalasso)
SD_MSE_VSM <- sd(MSE_VSM)
SD_MSE_locfit <- sd(MSE_locfit)

mean_MSE_ridge
mean_MSE_VSM
mean_MSE_lasso
mean_MSE_adalasso
mean_MSE_locfit

SD_MSE_ridge
SD_MSE_VSM
SD_MSE_lasso
SD_MSE_adalasso
SD_MSE_locfit

cat("monte_num",monte_num,"n_sample",n_sample,"true_stan_dev",true_stan_dev,
"\n","mean_MSE_VSM",mean_MSE_VSM,"SD_MSE_VSM",SD_MSE_VSM,"\n",
"mean_MSE_ridge",mean_MSE_ridge,"SD_MSE_ridge",SD_MSE_ridge,"\n",
"mean_MSE_lasso",mean_MSE_lasso,"SD_MSE_lasso",SD_MSE_lasso,"\n",
"mean_MSE_adalasso",mean_MSE_adalasso,"SD_MSE_adalasso",SD_MSE_adalasso,"\n",
"mean_MSE_locfit",mean_MSE_locfit,"SD_MSE_locfit",SD_MSE_locfit,"\n")
