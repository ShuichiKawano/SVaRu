VSM_main_function <- function(n_monte, n_sample, start_data, end_data, true_stan_dev
                              , true_function, basis_num_vec, width_para, start_smooth
                              , end_smooth, n_smooth, n_gamma, start_gamma_1
                              , end_gamma_1, start_gamma_2, end_gamma_2) {

  source("sample_generation.R")
  source("True_Func.R")
  source("VSM_GIC.R")
  source("Gauss_Kernel.R")
  set.seed(0)
  
  #####-----setting the parameters start-----#
  MSE_ridge_vec <- 0 * seq(1,1,length = n_monte)
  MSE_lasso_vec <- 0 * seq(1,1,length = n_monte)
  MSE_VSM_vec <- 0 * seq(1,1,length = n_monte)
  MSE_adalasso_vec <- 0 * seq(1,1,length = n_monte)
  MSE_locfit_vec <- 0 * seq(1,1,length = n_monte)
  
  smooth_vec <- seq(start_smooth, end_smooth, length = n_smooth)
  gam_1_vec <- seq(start_gamma_1, end_gamma_1, length = n_gamma)
  gam_2_vec <- seq(start_gamma_2, end_gamma_2, length = n_gamma)
  #####-----setting the parameters end-----#
  
  #####-----Monte Carlo simulation start-----#
    #VSM-start
    opt_paras_VSM <- VSM_GIC(exp_data, res_data, basis_num_vec, smooth_vec, width_para, gam_1_vec, gam_2_vec)
    opt_n_basis <- opt_paras_VSM[[1]]
    opt_gam_1 <- opt_paras_VSM[[2]]
    opt_gam_2 <- opt_paras_VSM[[3]]
    VSM_opt_coef <- opt_paras_VSM[[4]]
    VSM_reg_var <- opt_paras_VSM[[5]]
    VSM_opt_lam <- opt_paras_VSM[[6]] 
    #VSM-end
    #
    #basis function VSM, ridge, lasso and adalasso
    width_para_vec <- width_para * seq(1, 1, length = opt_n_basis)
    basis_mean_point <- seq(start_data, end_data,length = opt_n_basis)
    Basis_function <- Gauss_Kernel(exp_data, basis_mean_point, width_para_vec)
    Basis_function2 <- Gauss_Kernel(exp_data2, basis_mean_point, width_para_vec)
    
    #VSM
    est_VSM <- Basis_function %*% VSM_opt_coef 
    est_VSM2 <- Basis_function2 %*% VSM_opt_coef 
    #ridge
    opt_ridge_coef <- ridge_GIC(Basis_function, res_data, smooth_vec)[[1]]
    est_ridge <- Basis_function %*% opt_ridge_coef
    est_ridge2 <- Basis_function2 %*% opt_ridge_coef
    #lasso
    CV_Lasso <- cv.glmnet(Basis_function, res_data, offset = NULL, alpha = 1, nlambda = 100, standardize = FALSE)
    Lasso_coef <- coef(CV_Lasso)
    Lasso_coef <- as.vector(Lasso_coef)
    Lasso_int <- Lasso_coef[1]
    Lasso_coef <- Lasso_coef[2:length(Lasso_coef)]
    est_lasso <- Basis_function %*% Lasso_coef + Lasso_int
    est_lasso2 <- Basis_function2 %*% Lasso_coef + Lasso_int
    
    CV_Adalasso <- adalasso(Basis_function, res_data, k=5, use.Gram = FALSE, both = TRUE)
    Adalasso_int <- CV_Adalasso$intercept.adalasso
    Adalasso_coef <- CV_Adalasso$coefficients.adalasso
    Adalasso_coef <- as.vector(Adalasso_coef)
    Adalasso_lambda <- CV_Adalasso$cv.adalasso
    est_adalasso <- Basis_function%*%Adalasso_coef + Adalasso_int
    est_adalasso2 <- Basis_function2%*%Adalasso_coef + Adalasso_int
    
    alpha_candidate <- seq(0.01, 5.0, by=0.01)
    AIC <- summary(aicplot(res_data~exp_data, alpha=alpha_candidate))[ ,2]
    fit <- locfit(res_data~exp_data, alpha=alpha_candidate[which.min(AIC)])
    est_locfit <- predict(fit, exp_data)
    est_locfit2 <- predict(fit, exp_data2)

    dev.set(1)
    plot(exp_data2, est_VSM2, xlim=c(start_data,end_data), ylim=c(min(res_data)-0.2,max(res_data)+0.2),
         type = "l", xlab="", ylab="", lty = 1, xaxt="n", yaxt="n", lwd=2)
    par(new=T)
    plot(exp_data2, res_data2, xlim=c(start_data,end_data), ylim=c(min(res_data)-0.2,max(res_data)+0.2),
         xlab="", ylab="", xaxt="n", yaxt="n", type="l", col=gray(0.7), lwd=1)
    panel.first=grid(8,8)
    dev.set(1)
    plot(exp_data2, est_ridge2, xlim=c(start_data,end_data), ylim=c(min(res_data)-0.2,max(res_data)+0.2),
         type = "l", xlab="", ylab="", lty = 1, xaxt="n", yaxt="n", lwd=2)
    par(new=T)
    plot(exp_data2, res_data2, xlim=c(start_data,end_data), ylim=c(min(res_data)-0.2,max(res_data)+0.2),
         xlab="", ylab="", xaxt="n", yaxt="n", type="l", col=gray(0.7), lwd=1)
    panel.first=grid(8,8)
    dev.set(1)
    plot(exp_data2, est_lasso2, xlim=c(start_data,end_data), ylim=c(min(res_data)-0.2,max(res_data)+0.2),
         type = "l", xlab="", ylab="", lty = 1, xaxt="n", yaxt="n", lwd=2)
    par(new=T)
    plot(exp_data2, res_data2, xlim=c(start_data,end_data), ylim=c(min(res_data)-0.2,max(res_data)+0.2),
         xlab="", ylab="", xaxt="n", yaxt="n", type="l", col=gray(0.7), lwd=1)
    panel.first=grid(8,8)
    dev.set(1)
    plot(exp_data2, est_adalasso2, xlim=c(start_data,end_data), ylim=c(min(res_data)-0.2,max(res_data)+0.2),
         type = "l", xlab="", ylab="", lty = 1, xaxt="n", yaxt="n", lwd=2)
    par(new=T)
    plot(exp_data2, res_data2, xlim=c(start_data,end_data), ylim=c(min(res_data)-0.2,max(res_data)+0.2),
         xlab="", ylab="", xaxt="n", yaxt="n", type="l", col=gray(0.7), lwd=1)
    panel.first=grid(8,8)
    dev.set(1)
    plot(exp_data2, est_locfit2, xlim=c(start_data,end_data), ylim=c(min(res_data)-0.2,max(res_data)+0.2),
         type = "l", xlab="", ylab="", lty = 1, xaxt="n", yaxt="n", lwd=2)
    par(new=T)
    plot(exp_data2, res_data2, xlim=c(start_data,end_data), ylim=c(min(res_data)-0.2,max(res_data)+0.2),
         xlab="", ylab="", xaxt="n", yaxt="n", type="l", col=gray(0.7), lwd=1)
    panel.first=grid(8,8)

    #MSE
    MSE_ridge <- 0
    MSE_lasso <- 0
    MSE_VSM <- 0
    MSE_adalasso <- 0
    for (k in 1:length(te)){
      MSE_ridge = (1/length(te)) * abs(res_data2[k] - est_ridge2[k])^2 + MSE_ridge
      MSE_lasso = (1/length(te)) * abs(res_data2[k] - est_lasso2[k])^2 + MSE_lasso
      MSE_adalasso = (1/length(te)) * abs(res_data2[k] - est_adalasso2[k])^2 + MSE_adalasso
      MSE_VSM = (1/length(te)) * abs(res_data2[k] - est_VSM2[k])^2 + MSE_VSM
    }
    MSE_locfit <- mean( ( res_data2 - est_locfit2 )^2 )
  
  return(list(MSE_VSM, MSE_ridge, MSE_lasso, MSE_adalasso, MSE_locfit))
}
