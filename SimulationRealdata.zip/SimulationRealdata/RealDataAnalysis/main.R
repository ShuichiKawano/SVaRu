set.seed(0)
n_sample <- 201; all_n_sample <- 3216
r_sample <- sample(1:all_n_sample,all_n_sample)

source("VSM_main_function.R")
source("detailed_calculate.R")
source("sample_generation.R")
source("ridge_GIC.R")
source("Ite_Est_ridge.R")

library(MASS)
library(glmnet)
library(lqa)
library(parcor)
library(locfit)

MSE_VSM <- NULL
MSE_ridge <- NULL
MSE_lasso <- NULL
MSE_adalasso <- NULL
MSE_locfit <- NULL

for(ii in 1:(all_n_sample/n_sample)){

tr <- sort(r_sample[(n_sample*(ii-1)+1):(n_sample*ii)]); te <- (1:all_n_sample)[-tr]
exp_data <- tr/all_n_sample; exp_data2 <- te/all_n_sample
res_data <- as.vector(t(read.csv('station_avg2.csv',header=FALSE)))[tr]
res_data2 <- as.vector(t(read.csv('station_avg2.csv',header=FALSE)))[te]

start_data=0
end_data=1

### START tuning parameters ###
n_monte <- 1
basis_num_vec = 100
width_para = 10^(-3)

start_smooth <- 10^(-9)
end_smooth <- 10^(-1)
n_smooth <- 5

start_gamma_1 <- exp(-6)
end_gamma_1 <- exp(-4)
start_gamma_2 <- exp(-6)
end_gamma_2 <- exp(-4)
n_gamma <- 3		
### END tuning parameters ###

result_VSM <- VSM_main_function(n_monte, n_sample, start_data, end_data, true_stan_dev
                                , true_function, basis_num_vec, width_para, start_smooth, end_smooth
                                , n_smooth, n_gamma, start_gamma_1, end_gamma_1, start_gamma_2, end_gamma_2)

MSE_VSM <- c(MSE_VSM,result_VSM[[1]])
MSE_ridge <- c(MSE_ridge,result_VSM[[2]])
MSE_lasso <- c(MSE_lasso,result_VSM[[3]])
MSE_adalasso <- c(MSE_adalasso,result_VSM[[4]])
MSE_locfit <- c(MSE_locfit,result_VSM[[5]])

# cat(ii,"\n")
dev.off(); dev.off(); dev.off(); dev.off(); dev.off()

}

cat("MSE_vsm:",sprintf("%.4f",MSE_VSM),
"Ave:",sprintf("%.4f",mean(MSE_VSM)),"SD:",sprintf("%.4f",sd(MSE_VSM)),"\n")
cat("MSE_rid:",sprintf("%.4f",MSE_ridge),
"Ave:",sprintf("%.4f",mean(MSE_ridge)),"SD:",sprintf("%.4f",sd(MSE_ridge)),"\n")
cat("MSE_las:",sprintf("%.4f",MSE_lasso),
"Ave:",sprintf("%.4f",mean(MSE_lasso)),"SD:",sprintf("%.4f",sd(MSE_lasso)),"\n")
cat("MSE_ala:",sprintf("%.4f",MSE_adalasso),
"Ave:",sprintf("%.4f",mean(MSE_adalasso)),"SD:",sprintf("%.4f",sd(MSE_adalasso)),"\n")
cat("MSE_loc:",sprintf("%.4f",MSE_locfit),
"Ave:",sprintf("%.4f",mean(MSE_locfit)),"SD:",sprintf("%.4f",sd(MSE_locfit)),"\n")

