Ite_Est_ridge <- function(Basis_function, res_data, smooth_para){
  n_sample <- dim(Basis_function)[1]
  n_basis <- dim(Basis_function)[2]
  ridge_var_old <- 1
  s <- 1
  while (s > 10^(-10)){
    ridge_coef <- {solve(t(Basis_function) %*% Basis_function 
                         + n_basis * smooth_para * ridge_var_old * diag(n_basis))%*% t(Basis_function) %*% res_data}
    pre_point <- Basis_function %*% ridge_coef
    pre_point <- as.vector(pre_point)
    ridge_var <- (1/n_sample) * t(res_data - pre_point) %*% (res_data - pre_point)
    ridge_var <- as.numeric(ridge_var)
    s <- (ridge_var - ridge_var_old)^2
    ridge_var_old <- ridge_var
  }
  ridge_var <- ridge_var_old
  
  return(list(ridge_coef, ridge_var))
}
