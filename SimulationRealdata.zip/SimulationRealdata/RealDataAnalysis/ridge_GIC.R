ridge_GIC <- function(Basis_function, res_data, smooth_vec){
  
  n_sample <- dim(Basis_function)[1]
  n_basis <- dim(Basis_function)[2]
  n_smooth <- length(smooth_vec)
  
  Reg_Var_vec <- seq(0, 0,length = n_smooth)
  GIC_smooth_vec <- seq(0, 0,length = n_smooth)
  
  for (i in 1: length(smooth_vec)){
    smooth_para <- smooth_vec[i]
    Est_ridge <- Ite_Est_ridge(Basis_function, res_data, smooth_para)
    ridge_coef <- Est_ridge[[1]]
    ridge_var <- Est_ridge[[2]]
    Reg_Var_vec[i] <- ridge_var
    Lamda <- matrix(0, nrow = n_sample, ncol = n_sample)
    for (j in 1:n_sample){
      residual <- (res_data - Basis_function %*% ridge_coef)
      Lamda[j,j] <- residual[j]
    }
    N1 <- seq(1, 1, length = n_sample)
    #--------------matrix R------------------
    R1 <- (t(Basis_function) %*% Basis_function) + (n_sample * smooth_para * ridge_var * diag(n_basis));
    R2 <- (1/ridge_var) * t(Basis_function) %*% Lamda %*% N1
    R3 <-(1/ridge_var) * t(N1) %*% Lamda %*% Basis_function
    R4 <- n_sample/(2*ridge_var)
    
    R <- (1/(n_sample*ridge_var)) * rbind(cbind(R1, R2), cbind(R3, R4))
    #--------------matrix Q------------------
    Q1 <- {(1/ridge_var) * t(Basis_function) %*% Lamda %*% Lamda %*% Basis_function 
      - (smooth_para * diag(n_basis) * ridge_coef %*% t(N1) %*% Lamda %*% Basis_function)}
    Q2 <- {(1/(2*(ridge_var^2))) * t(Basis_function) %*% Lamda %*% Lamda %*% Lamda %*% N1 
      - (1/(2*ridge_var)) * t(Basis_function) %*% Lamda %*% N1}
    Q3 <- {(1/(2*ridge_var^2)) * t(N1) %*% Lamda %*% Lamda %*% Lamda %*% Basis_function
      -((1/(2*ridge_var)) * t(N1) %*% Lamda %*% Basis_function)}
    Q4 <- {(1/(4*ridge_var^3)) * t(N1) %*% Lamda %*% Lamda %*% Lamda %*% Lamda %*% N1 
      -(n_sample/(4*ridge_var))}
    
    Q <- (1/(n_sample * ridge_var)) * rbind(cbind(Q1, Q2), cbind(Q3, Q4))
#--------------GIC-----------------------
    tr <- ginv(R) %*% Q
    GIC_smooth_vec[i] <- n_sample *(log(2*pi)+1)+ n_sample *log(ridge_var) + 2 * sum(diag(tr))
  }
  min_GIC_smooth <- min(GIC_smooth_vec)
  for (t in 1:length(GIC_smooth_vec)){
    if (GIC_smooth_vec[t] == min_GIC_smooth){
      t_0 <- t
    }
  }
  opt_smooth_para <- smooth_vec[t_0]
  
  Est_ridge <- Ite_Est_ridge(Basis_function, res_data, opt_smooth_para)
  opt_ridge_coef <- Est_ridge[[1]]
  opt_ridge_var <- Est_ridge[[2]]

  return(list(opt_ridge_coef))

}
