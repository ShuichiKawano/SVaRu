Gauss_kernel_2dim <- function(exp_data_1, n_basis, width_para) {
  x <- exp_data_1
  y <- exp_data_1
  mean_bx <- seq(exp_data_1[1], exp_data_1[length(exp_data_1)],length = n_basis)
  mean_by <- seq(exp_data_1[1], exp_data_1[length(exp_data_1)],length = n_basis)
  
  Gaussian_kernel_2dim = matrix(1, nrow = n_sample, ncol = n_sample);
  Gaussian_vec_new <- seq(0, 1, length=n_sample^2)
  for (k_1 in 1:n_basis){
    for (k_2 in 1: n_basis){
      for (i in 1: n_sample){
        for (j in 1: n_sample){
          Gaussian_kernel_2dim[i, j] = exp( - ( (x[i] - mean_bx[k_1])^2 + (y[j] - mean_by[k_2])^2 ) / width_para^2 );
        }
      }
      Gaussian_vec <- as.vector(Gaussian_kernel_2dim)
      Gaussian_vec_new <- cbind(Gaussian_vec_new, Gaussian_vec)
    }
  }
  Gaussian_vec_new <- Gaussian_vec_new[,1:n_basis^2]
  return(Gaussian_vec_new)
}
