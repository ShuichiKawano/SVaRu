library(MASS)
library(glmnet)
library(lqa)
library(ppls)
library(Epi)
library(GeneNet)
library(parcor)
library(locfit)

path <- getwd()
setwd(path)
getwd()
source("sample_generation_2dim.R")
source("VSM_surface_GIC.R")
source("Gauss_Kernel_2dim.R")
source("VSM_Est_HyperTuning_fix_2dim.R")
source("VSM_GIC_Value.R")
source("VSM_main_surface.R")
source("Ite_Est_ridge.R")
source("ridge_GIC.R")
source("True_Func.R")
setwd("./VSM_GIC_Values")
getwd()
source("Func_eta.R")
source("lambda.R")
source("log_likelihood.R")
source("w_p.R")
source("w_p_p.R")
source("w_p_p1.R")
source("w_p_p2.R")
source("w_p_p3.R")
setwd(path)

### START tuning parameter ###
monte_num <- 1  # the number of simulations
n_sample <- 50  # sample size
true_stan_dev <- sqrt(0.2) # standard deviation of errors

basis_num_vec = 11
width_para = 10^(-1)

start_smooth <- 10^(-9)
end_smooth <- 10^(-1)
n_smooth <- 5

start_gam1 <- exp(-3)
end_gam1 <- exp(-3)
start_gam2 <- exp(-3)
end_gam2 <- exp(-3)
n_gam <- 1
### END tuning parameter ###

######
start_data=0
end_data=1

result_VSM <- VSM_main_surface(monte_num, n_sample, start_data, end_data, true_stan_dev
                               , true_func_num, basis_num_vec, width_para, start_smooth, end_smooth
                               , n_smooth, n_gam, start_gam1, end_gam1, start_gam2, end_gam2)

MSE_VSM <- result_VSM[[1]]
MSE_ridge <- result_VSM[[2]]
MSE_lasso <- result_VSM[[3]]
MSE_adalasso <- result_VSM[[4]]
gam_1 <- result_VSM[[5]]
gam_2 <- result_VSM[[6]]
MSE_locfit <- result_VSM[[7]]

mean_MSE_ridge <- mean(MSE_ridge)
mean_MSE_lasso <- mean(MSE_lasso)
mean_MSE_adalasso <- mean(MSE_adalasso)
mean_MSE_VSM <- mean(MSE_VSM)
mean_gam_1 <- mean(gam_1)
mean_gam_2 <- mean(gam_2)
mean_MSE_locfit <- mean(MSE_locfit)

SD_MSE_ridge <- sd(MSE_ridge)
SD_MSE_lasso <- sd(MSE_lasso)
SD_MSE_adalasso <- sd(MSE_adalasso)
SD_MSE_VSM <- sd(MSE_VSM)
SD_gam_1 <- sd(gam_1)
SD_gam_2 <- sd(gam_2)
SD_MSE_locfit <- sd(MSE_locfit)

mean_MSE_VSM
mean_MSE_ridge
mean_MSE_lasso
mean_MSE_adalasso
mean_gam_1
mean_gam_2
mean_MSE_locfit

SD_MSE_VSM
SD_MSE_ridge
SD_MSE_lasso
SD_MSE_adalasso
SD_gam_1
SD_gam_2
SD_MSE_locfit

cat("monte_num",monte_num,"n_sample",n_sample,"true_stan_dev",true_stan_dev,
"\n","mean_MSE_VSM",mean_MSE_VSM,"SD_MSE_VSM",SD_MSE_VSM,"\n",
"mean_MSE_ridge",mean_MSE_ridge,"SD_MSE_ridge",SD_MSE_ridge,"\n",
"mean_MSE_lasso",mean_MSE_lasso,"SD_MSE_lasso",SD_MSE_lasso,"\n",
"mean_MSE_adalasso",mean_MSE_adalasso,"SD_MSE_adalasso",SD_MSE_adalasso,"\n",
"mean_MSE_locfit",mean_MSE_locfit,"SD_MSE_locfit",SD_MSE_locfit,"\n")
