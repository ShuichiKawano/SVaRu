sample_generation_2dim <- function(n_sample, start_data, end_data, true_stan_dev) {
  
  exp_data_1<- seq(start_data, end_data, length=n_sample)
  exp_data_2<- exp_data_1

  surface_simu1 <- function(exp_data_1, exp_data_2){
    exp( - 30 * ((exp_data_1-0.25)^2 + (exp_data_2-0.25)^2)) + exp( - 30 * ((exp_data_1-0.25)^2 + (exp_data_2-0.75)^2))  + exp( - 30 * ((exp_data_1-0.75)^2 + (exp_data_2-0.25)^2)) + 
    exp( - 100 * ((exp_data_1- (0.5 + 0.1))^2 + (exp_data_2-(0.5 + 0.1))^2)) + exp( - 100 * ((exp_data_1- (0.5 + 0.4))^2 + (exp_data_2- (0.5 + 0.4))^2))  + exp( - 100 * ((exp_data_1- (0.5 + 0.4))^2 + (exp_data_2-(0.5 + 0.1))^2)) + exp( - 100 * ((exp_data_1- (0.5 + 0.1))^2 + (exp_data_2- (0.5 + 0.4))^2))
 	}

  z <- outer(exp_data_1,exp_data_2,surface_simu1)
  z[is.na(z)] <- 1
  true_surface <- z
  x <- exp_data_1
  y <- exp_data_2

  res_data <- matrix (1,n_sample, n_sample)
  for (i in 1:n_sample){
    for (j in 1:n_sample){
      res_data[i, j] <- z[i,j] + rnorm(1, mean=0, sd = true_stan_dev)
    }
  }

  res_data_vec <- as.vector(res_data)
  
 return(list(exp_data_1, exp_data_2, true_surface, res_data, res_data_vec))
}
