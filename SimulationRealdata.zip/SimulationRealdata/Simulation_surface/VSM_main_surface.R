VSM_main_surface <- function(monte_num, n_sample, start_data, end_data, true_stan_dev
                              , true_function, basis_num_vec, width_para, start_smooth
                              , end_smooth, n_smooth, n_gam, start_gam1
                              , end_gam1, start_gam2, end_gam2) {

  set.seed(0)
  
  #####-----setting the parameters start-----#
  MSE_ridge_vec <- 0 * seq(1,1,length = monte_num)
  MSE_lasso_vec <- 0 * seq(1,1,length = monte_num)
  MSE_VSM_vec <- 0 * seq(1,1,length = monte_num)
  MSE_adalasso_vec <- 0 * seq(1,1,length = monte_num)
  MSE_locfit_vec <- 0 * seq(1,1,length = monte_num)
  
  smooth_vec <- seq(start_smooth, end_smooth, length = n_smooth)
  gam_1_vec <- seq(start_gam1, end_gam1, length = n_gam)
  gam_2_vec <- seq(start_gam2, end_gam2, length = n_gam)
  #####-----setting the parameters end-----#
  opt_gam_1_vec <- seq(1, 1, length = monte_num)
  opt_gam_2_vec <- seq(1, 1, length = monte_num)
  
  #####-----Monte Carlo simulation start-----#
  for (q in 1: monte_num){
    sample <- sample_generation_2dim(n_sample, start_data, end_data, true_stan_dev)
    exp_data_1 <- sample[[1]]
    exp_data_2 <- sample[[2]]
    true_surface <- sample[[3]]
    true_surface_mat <- matrix(true_surface, ncol=n_sample)
    res_data_mat <- sample[[4]]
    res_data_vec <- sample[[5]]
    
    #VSM-start
    opt_paras_VSM <- VSM_surface_GIC(exp_data_1, res_data_vec, basis_num_vec, smooth_vec, width_para, gam_1_vec, gam_2_vec)
    opt_n_basis <- opt_paras_VSM[[1]]
    opt_gam_1 <- opt_paras_VSM[[2]]
    opt_gam_2 <- opt_paras_VSM[[3]]
    VSM_opt_coef <- opt_paras_VSM[[4]]
    VSM_reg_var <- opt_paras_VSM[[5]]
    VSM_opt_lam <- opt_paras_VSM[[6]] 
    #VSM-end
    opt_gam_1_vec[q] <- opt_gam_1
    opt_gam_2_vec[q] <- opt_gam_2
    #
    
    #basis function VSM, ridge, lasso and adalasso
    opt_Basis_function_2dim <- Gauss_kernel_2dim(exp_data_1, opt_n_basis, width_para)

    #VSM
    est_VSM <- opt_Basis_function_2dim %*% VSM_opt_coef
    est_VSM_mat <- matrix(est_VSM, ncol=n_sample)
    est_VSM[is.na(est_VSM)] <- 1
    x <- exp_data_1
    y <- exp_data_2

    #ridge
    smooth_para <- 10^(-6)
    est_Ridge <- opt_Basis_function_2dim %*% solve( t(opt_Basis_function_2dim) %*% opt_Basis_function_2dim + smooth_para * diag(opt_n_basis^2))  %*% t(opt_Basis_function_2dim) %*% res_data_vec
    est_Ridge_mat <- matrix(est_Ridge, ncol=n_sample)
    est_Ridge[is.na(est_Ridge)] <- 1

    #lasso
    CV_Lasso <- cv.glmnet(opt_Basis_function_2dim, res_data_vec, offset = NULL, alpha = 1, nlambda = 100, standardize = FALSE)
    Lasso_coef <- coef(CV_Lasso)
    Lasso_coef <- as.vector(Lasso_coef)
    Lasso_int <- Lasso_coef[1]
    Lasso_coef <- Lasso_coef[2:length(Lasso_coef)]
    est_lasso <- opt_Basis_function_2dim %*% Lasso_coef + Lasso_int
    est_lasso_mat <-  matrix(est_lasso, ncol=n_sample)

    #Adaptive lasso
    CV_Adalasso <- adalasso(opt_Basis_function_2dim, res_data_vec, k=3, use.Gram = FALSE, both = TRUE)
    Adalasso_int <- CV_Adalasso$intercept.adalasso
    Adalasso_coef <- CV_Adalasso$coefficients.adalasso
    Adalasso_coef <- as.vector(Adalasso_coef)
    Adalasso_lambda <- CV_Adalasso$cv.adalasso
    est_adalasso <- opt_Basis_function_2dim%*%Adalasso_coef + Adalasso_int
    est_adalasso_mat <-  matrix(est_adalasso, ncol=n_sample)

    nn_candidate <- seq(0.01, 0.9, by=0.01)
    AIC <- nn_candidate
    Exp_data_1 <- rep(exp_data_1, length(exp_data_2))
    Exp_data_2 <- rep(exp_data_2, each = length(exp_data_1))
    for(i in 1:length(AIC)) AIC[i] <- as.numeric(aic(locfit(res_data_vec~lp(Exp_data_1, Exp_data_2, nn=nn_candidate[i])))[4])
    fit <- locfit(res_data_vec~lp(Exp_data_1, Exp_data_2, nn=nn_candidate[which.min(AIC)]))
    est_locfit <- predict(fit, lp(Exp_data_1, Exp_data_2, nn=nn_candidate[which.min(AIC)]))
    est_locfit_mat <- matrix(est_locfit, ncol=n_sample)

    dev.set(1)
    persp(x, y, true_surface_mat, theta = 30, phi = 30, expand = 0.5, col = "magenta")
    panel.first=grid(8,8)
    dev.set(1)
    persp(x, y, est_VSM_mat, theta = 30, phi = 30, expand = 0.5, col = "lightblue")
    panel.first=grid(8,8)
    dev.set(1)
    persp(x, y, est_Ridge_mat, theta = 30, phi = 30, expand = 0.5, col = "red")
    panel.first=grid(8,8)
    dev.set(1)
    persp(x, y, est_lasso_mat, theta = 30, phi = 30, expand = 0.5, col = "yellow")
    panel.first=grid(8,8)
    dev.set(1)
    persp(x, y, est_adalasso_mat, theta = 30, phi = 30, expand = 0.5, col = "green")
    panel.first=grid(8,8)
    dev.set(1)
    persp(x, y, est_locfit_mat, theta = 30, phi = 30, expand = 0.5, col = "aquamarine4")

    #MSE
    MSE_ridge <- 0
    MSE_lasso <- 0
    MSE_VSM <- 0
    MSE_adalasso <- 0
    for (k in 1:n_sample^2){
      MSE_ridge = (1/n_sample^2) * (true_surface[k] - est_Ridge[k])^(2) + MSE_ridge
      MSE_lasso = (1/n_sample^2) * (true_surface[k] - est_lasso[k])^(2) + MSE_lasso
      MSE_adalasso = (1/n_sample^2) * (true_surface[k] - est_adalasso[k])^(2) + MSE_adalasso
      MSE_VSM = (1/n_sample^2) * (true_surface[k] - est_VSM[k])^(2) + MSE_VSM
    }
    MSE_ridge_vec[q] = MSE_ridge
    MSE_lasso_vec[q] = MSE_lasso
    MSE_VSM_vec[q] = MSE_VSM
    MSE_adalasso_vec[q] = MSE_adalasso
    MSE_locfit_vec[q] = mean( ( true_surface - est_locfit )^2 )

  }

  return(list(MSE_VSM_vec, MSE_ridge_vec, MSE_lasso_vec, MSE_adalasso_vec, opt_gam_1_vec, opt_gam_2_vec, MSE_locfit_vec))
}
