#This program is used to implement proposed GIC in VSM

VSM_surface_GIC <- function(exp_data_1, res_data_vec, basis_num_vec, smooth_vec, width_para, gam_1_vec, gam_2_vec){
  
  n_sample <- length(exp_data_1)
  exp_data_2 <- exp_data_1
  n_gamma <- length(gam_1_vec)
  VSM_GIC_Mat <- matrix (0, nrow = n_gamma, ncol= (length(basis_num_vec) * n_gamma))
  for (k in 1:length(basis_num_vec)){
    n_basis <- basis_num_vec[k];
    width_para <- 10^(-1)
    Basis_function_2dim <- Gauss_kernel_2dim(exp_data_1, n_basis, width_para)
    opt_GIC_smooth <- 10^(-1)
    for (i in 1: n_gamma){
      for (j in 1: n_gamma){
        gam_1 = gam_1_vec[i]
        gam_2 = gam_2_vec[j]
        VSM_Est_paras <- VSM_Est_HyperTuning_fix_2dim(Basis_function_2dim, res_data_vec, gam_1, gam_2, opt_GIC_smooth)
        
        
        VSM_coef <- VSM_Est_paras[[1]]
        VSM_coef <- as.vector(VSM_coef)
        VSM_Lam <- VSM_Est_paras[[2]]
        VSM_Lam <- as.vector(VSM_Lam)
        est_VSM <- Basis_function_2dim %*% VSM_coef
        reg_var <- (1/n_sample) * t(res_data_vec - est_VSM) %*% (res_data_vec - est_VSM)
        GIC_RQ <- VSM_GIC_Value(res_data_vec, Basis_function_2dim, gam_1, gam_2, VSM_coef, reg_var)
        VSM_GIC_Mat[i, j + (k-1) * length(gam_1_vec)] <- n_sample * (log(2 * pi) + 1) + n_sample * log(reg_var) + 2 * sum(diag(GIC_RQ))
      }
    }
  }
  
  min_GIC_VSM = min(min(min(VSM_GIC_Mat)));
  for (k in 1: length(basis_num_vec)){
    for (i in 1:n_gamma){
      for (j in 1:n_gamma){
        if(VSM_GIC_Mat[i, j + (k-1) * n_gamma] == min_GIC_VSM){
          k_0 <- k
          i_0 <- i
          j_0 <- j
        }
      }
    }
  }
  opt_n_basis = basis_num_vec[k_0]
  opt_gam_1 = gam_1_vec[i_0]
  opt_gam_2 = gam_2_vec[j_0]
  
  VSM_basis_mean_point <- seq(start_data, end_data,length = opt_n_basis)
  VSM_opt_Basis_function <- Gauss_kernel_2dim(exp_data_1, n_basis, width_para)
  VSM_opt_est_paras <-VSM_Est_HyperTuning_fix_2dim(VSM_opt_Basis_function, res_data_vec, opt_gam_1, opt_gam_2, opt_GIC_smooth)
  VSM_opt_coef <- VSM_opt_est_paras[[1]]
  VSM_opt_lam <- VSM_opt_est_paras[[2]]
  VSM_reg_var <- (1/n_sample) * t(res_data_vec - VSM_opt_Basis_function %*% VSM_opt_coef) %*% (res_data_vec - VSM_opt_Basis_function %*% VSM_opt_coef)
  return(list(opt_n_basis, opt_gam_1, opt_gam_2, VSM_opt_coef, VSM_reg_var, VSM_opt_lam))
}
