

log_likelihood <- function(reg_var, Basis_function, p1, p2){
  Value <- {
    Value <- -(1/reg_var) * Basis_function[p1, ] %*% Basis_function[p2, ]
  }
  
  return(Value)
  
}

#complete