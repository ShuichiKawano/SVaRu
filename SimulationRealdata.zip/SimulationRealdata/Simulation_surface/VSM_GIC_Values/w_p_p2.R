#lをw_pとw_{p-2}で微分したもの

w_p_p_minus_2 <- function(VSM_coef, reg_var, Basis_function, gam_1, gam_2, p){
  a <- 32*gam_1^(2)*gam_2^(3)*VSM_coef[p]^(-3)*VSM_coef[p-2]^(-3)*Func_eta(VSM_coef, p-1, gam_1, gam_2)^(-3)
  b <- 4 * gam_1 * gam_2 ^2 * VSM_coef[p]^(-3) * Func_eta(VSM_coef, p-1, gam_1, gam_2)^(-2)
  c <- -2 * gam_2 * Func_eta(VSM_coef, p-2, gam_1, gam_2)^(-2) * (VSM_coef[p-2] + 4 * gam_1 * gam_2 * VSM_coef[p-2]^(-3))
  d <- 4 * gam_1 * gam_2^2 * VSM_coef[p-2]^(-3) * Func_eta(VSM_coef, p-1, gam_1, gam_2)^(-2)
  e <- c <- -2 * gam_2 * Func_eta(VSM_coef, p, gam_1, gam_2)^(-2) * (VSM_coef[p] + 4 * gam_1 * gam_2 * VSM_coef[p]^(-3))
  
  Value <- {log_likelihood(reg_var, Basis_function, p, p-2)
      -(1/2)*(a * VSM_coef[p-1]^(2))
      -(gam_1/2)*(-2*(a*(lambda(VSM_coef, p-2, gam_1, gam_2)-lambda(VSM_coef, p-1, gam_1, gam_2)) + b*(c-d))
                -2*(e*d + lambda(VSM_coef, p, gam_1, gam_2) * a)+2*(d * b + lambda(VSM_coef, p-1, gam_1, gam_2) * a))
      +(gam_2/2) * (a * lambda(VSM_coef, p-1, gam_1, gam_2)^(-1) - b * lambda(VSM_coef, p-1, gam_1, gam_2)^(-2) * d)}
  
  return(Value)
}

#lをw_pとw_{p+2}で微分したもの

w_p_p_plus_2 <- function(VSM_coef, reg_var, Basis_function, gam_1, gam_2, p){
  a1 <- 32*gam_1^(2)*gam_2^(3)*VSM_coef[p]^(-3)*VSM_coef[p+2]^(-3)*Func_eta(VSM_coef, p+1, gam_1, gam_2)^(-3)
  b1 <- 4 * gam_1 * gam_2 ^2 * VSM_coef[p]^(-3) * Func_eta(VSM_coef, p+1, gam_1, gam_2)^(-2)
  c1 <- -2 * gam_2 * Func_eta(VSM_coef, p+2, gam_1, gam_2)^(-2) * (VSM_coef[p+2] + 4 * gam_1 * gam_2 * VSM_coef[p+2]^(-3))
  d1 <- 4 * gam_1 * gam_2^2 * VSM_coef[p+2]^(-3) * Func_eta(VSM_coef, p+1, gam_1, gam_2)^(-2)
  e1 <- c <- -2 * gam_2 * Func_eta(VSM_coef, p, gam_1, gam_2)^(-2) * (VSM_coef[p] + 4 * gam_1 * gam_2 * VSM_coef[p]^(-3))
  
  Value <- 
    {log_likelihood(reg_var, Basis_function, p, p+2)
      -(1/2)*(a1 * VSM_coef[p+1]^(2))
      -(gam_1/2)*(-2*(a1*(lambda(VSM_coef, p+2, gam_1, gam_2)-lambda(VSM_coef, p+1, gam_1, gam_2)) + b1*(c1-d1))
      -2*(e1*d1 + lambda(VSM_coef, p, gam_1, gam_2) * a1) + 2*(d1 * b1 + lambda(VSM_coef, p+1, gam_1, gam_2) * a1))
      +(gam_2/2) * (a1 * lambda(VSM_coef, p+1, gam_1, gam_2)^(-1) - b1 * lambda(VSM_coef, p+1, gam_1, gam_2)^(-2) * d1)}
  
  return(Value)
}



#complete