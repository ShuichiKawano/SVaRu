#lをw_pとw_{p-3}で微分したもの

w_p <- function(res_data, VSM_coef, reg_var, Basis_function, gam_1, gam_2, p){
  
  aa <- 4 * gam_1 * gam_2^2 * VSM_coef[p]^(3)*Func_eta(VSM_coef, p-1, gam_1, gam_2)^(-2)
  bb <- -2 * gam_2 *Func_eta(VSM_coef, p, gam_1, gam_2)^(-2) * (VSM_coef[p] + 4 * gam_1 *gam_2 * VSM_coef[p]^(-3))
  cc <- 4 * gam_1 * gam_2^2 * VSM_coef[p]^(3)*Func_eta(VSM_coef, p+1, gam_1, gam_2)^(-2)
  
  Value <- {
    (1/reg_var) * sum( (res_data - Basis_function[p,] %*% VSM_coef) %*% t(Basis_function[p,]) )
    -(1/2) * (aa * VSM_coef[p-1]^(2) + bb * VSM_coef[p]^(2) + 2 * lambda(VSM_coef, p, gam_1, gam_2) * VSM_coef[p] + cc *  VSM_coef[p+1]^(2))
    -(gam_1 / 2) * (-2 * cc * (lambda(VSM_coef, p+2, gam_1, gam_2) -lambda(VSM_coef, p+1, gam_1, gam_2))
                    -2 * (cc * lambda(VSM_coef, p, gam_1, gam_2) + lambda(VSM_coef, p+1, gam_1, gam_2) * bb)
                    +4 * lambda(VSM_coef, p, gam_1, gam_2) * bb 
                    -2 * (bb * lambda(VSM_coef, p-1, gam_1, gam_2) + lambda(VSM_coef, p, gam_1, gam_2) * aa)
                    +2 * lambda(VSM_coef, p-1, gam_1, gam_2) * aa)
    +(gam_2/2) * (aa * lambda(VSM_coef, p-1, gam_1, gam_2)^(-1) 
                  + bb * lambda(VSM_coef, p, gam_1, gam_2)^(-1) 
                  + cc * lambda(VSM_coef, p+1, gam_1, gam_2)^(-1))
  }
  return(Value)
}

#complete