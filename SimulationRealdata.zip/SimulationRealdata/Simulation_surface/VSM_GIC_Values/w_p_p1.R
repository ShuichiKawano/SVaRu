#lをw_pとw_{p-1}で微分したもの

w_p_p_minus_1 <- function(VSM_coef, reg_var, Basis_function, gam_1, gam_2, p){
  
  a2 <- -16*gam_1*gam_2^(2)*Func_eta(VSM_coef, p-1, gam_1, gam_2)^(-3)*VSM_coef[p]^(-3)*(VSM_coef[p-1] - 4*gam_1*gam_2*VSM_coef[p-1]^(-3))
  b2 <- 4 * gam_1 * gam_2 ^2 * VSM_coef[p]^(-3) * Func_eta(VSM_coef, p-1, gam_1, gam_2)^(-2)
  c2 <- -16*gam_1*gam_2*Func_eta(VSM_coef, p, gam_1, gam_2)^(-3)*VSM_coef[p-1]^(-3)*(VSM_coef[p] + 4*gam_1*gam_2*VSM_coef[p]^(-3))
  d2 <- 4 * gam_1 * gam_2^(2) * VSM_coef[p-1]^(-3) * Func_eta(VSM_coef, p, gam_1, gam_2)^(-2)
  e2 <- 4 * gam_1 * gam_2^2 * VSM_coef[p-1]^(-3) * Func_eta(VSM_coef, p-2, gam_1, gam_2)
  f2 <- -2 * gam_2 * Func_eta(VSM_coef, p-1, gam_1, gam_2)^(-2) * (VSM_coef[p-1] - 4 * gam_1 * gam_2 * VSM_coef[p-1]^(-3))
  g2 <- 4 * gam_1 * gam_2^2 * VSM_coef[p]^(-3) * Func_eta(VSM_coef, p+1, gam_1, gam_2)^(-2)
  h2 <- -2 * gam_2 * Func_eta(VSM_coef, p, gam_1, gam_2)^(-2) * (VSM_coef[p] + 4 * gam_1 * gam_2 * VSM_coef[p]^(-3))

  Value <- 
    {log_likelihood(reg_var, Basis_function, p, p-1)
     -(1/2)*(a2 * VSM_coef[p-1]^(2) + 2 * b2 * VSM_coef[p-1] + c2 * VSM_coef[p]^(2) + 2 * d2 * VSM_coef[p])
     -(gam_1/2)*(- 2 * ( a2 * (lambda(VSM_coef, p-2, gam_1, gam_2) - lambda(VSM_coef, p-1, gam_1, gam_2)) + b2 * (e2-f2) ) 
                - 2 * (g2 * d2 + lambda(VSM_coef, p+1, gam_1, gam_2) * c2)
                + 4 * (d2 * h2 + lambda(VSM_coef, p, gam_1, gam_2) * c2)
                - 2 * (c2 * lambda(VSM_coef, p-1, gam_1, gam_2) + h2 * f2 + d2 * b2 + lambda(VSM_coef, p, gam_1, gam_2) * a2) 
                + 2 * (f2 * b2 + lambda(VSM_coef, p-1, gam_1, gam_2) * a2))
    +(gam_2/2) * (a2*lambda(VSM_coef, p-1, gam_1, gam_2)^(-1) - b2 * lambda(VSM_coef, p-1, gam_1, gam_2)^(-2) * f2
                  + c2 * lambda(VSM_coef, p, gam_1, gam_2)^(-1) 
                  - h2 * lambda(VSM_coef, p, gam_1, gam_2)^(-2) * d2)}
  
  return(Value)
}

#lをw_pとw_{p+1}で微分したもの

w_p_p_plus_1 <- function(VSM_coef, reg_var, Basis_function, gam_1, gam_2, p){
  
  a3 <- -16*gam_1*gam_2^(2)*Func_eta(VSM_coef, p, gam_1, gam_2)^(-3)*VSM_coef[p+1]^(-3)*(VSM_coef[p] - 4*gam_1*gam_2*VSM_coef[p]^(-3))
  b3 <- 4 * gam_1 * gam_2 ^2 * VSM_coef[p+1]^(-3) * Func_eta(VSM_coef, p, gam_1, gam_2)^(-2)
  c3 <- -16*gam_1*gam_2^2*Func_eta(VSM_coef, p+1, gam_1, gam_2)^(-3)*VSM_coef[p]^(-3)*(VSM_coef[p+1] + 4*gam_1*gam_2*VSM_coef[p+1]^(-3))
  d3 <- 4 * gam_1 * gam_2^(2)  * VSM_coef[p]^(-3) * Func_eta(VSM_coef, p+1, gam_1, gam_2)^(-2)
  e3 <- 4 * gam_1 * gam_2^2 * VSM_coef[p+1]^(-3) * Func_eta(VSM_coef, p+2, gam_1, gam_2)
  f3 <- -2 * gam_2 * Func_eta(VSM_coef, p+1, gam_1, gam_2)^(-2) * (VSM_coef[p+1] - 4 * gam_1 * gam_2 * VSM_coef[p+1]^(-3))
  g3 <- -2 * gam_2 * Func_eta(VSM_coef, p, gam_1, gam_2)^(-2) * (VSM_coef[p] - 4 * gam_1 * gam_2 * VSM_coef[p]^(-3))
  h3 <- 4 * gam_1 * gam_2^2 * VSM_coef[p]^(-3) * Func_eta(VSM_coef, p-1, gam_1, gam_2)^(-2)
  
  
  Value <- 
    {log_likelihood(reg_var, Basis_function, p, p+1)
      -(1/2)*(a3 * VSM_coef[p]^(2) + 2 * b3 * VSM_coef[p] + c3 * VSM_coef[p+1]^(2) + 2 * d3 * VSM_coef[p])
      -(gam_1/2)*(- 2 * ( c3 * (lambda(VSM_coef, p+2, gam_1, gam_2) - lambda(VSM_coef, p+1, gam_1, gam_2)) + d3 * (e3-f3) ) 
              + 2 * (f3 * d3 + lambda(VSM_coef, p+1, gam_1, gam_2) * c3)
              - 2 * (c3 * lambda(VSM_coef, p, gam_1, gam_2) + d3 * b3 + f3 * g3 + lambda(VSM_coef, p+1, gam_1, gam_2) * a3)
              + 4 * (b3 * g3 + lambda(VSM_coef, p, gam_1, gam_2) * a3)
              - 2 * (a3 * lambda(VSM_coef, p-1, gam_1, gam_2) + h3 * h3)) 
    +(gam_2/2) * (a3*lambda(VSM_coef, p, gam_1, gam_2)^(-1) - g3 * lambda(VSM_coef, p, gam_1, gam_2)^(-2) * b3 
                + c3 * lambda(VSM_coef, p+1, gam_1, gam_2)^(-1) 
                - d3 * lambda(VSM_coef, p+1, gam_1, gam_2)^(-2) * f3)}

  return(Value)
}

#complete