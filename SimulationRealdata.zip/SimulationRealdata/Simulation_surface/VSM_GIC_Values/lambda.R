
lambda <- function(VSM_coef, p, gam_1, gam_2){
  Value <- gam_2 * (VSM_coef[p]^2 + 2 * gam_1 * gam_2 * (VSM_coef[p-1]^(-2) - 2 * VSM_coef[p]^(-2) + VSM_coef[p+1]^(-2)))^(-1)
  return(Value)
}