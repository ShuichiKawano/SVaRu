#k:k-th element of VSM_coef. 計算式のeta(k)のこと

Func_eta <- function(VSM_coef, p, gam_1, gam_2){
  Value <- VSM_coef[p]^2 + 2 * gam_1 * gam_2 * (VSM_coef[p-1]^(-2) - 2 * VSM_coef[p]^(-2) + VSM_coef[p+1]^(-2))
  return(Value)
}