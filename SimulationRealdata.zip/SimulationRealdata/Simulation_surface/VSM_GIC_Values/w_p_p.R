#lをw_kとw_kで微分したもの

w_p_p <- function(VSM_coef, reg_var, Basis_function, gam_1, gam_2, p){
  
  a4 <- 4*gam_1*gam_2^(2) * (-3 * VSM_coef[p]^(-4)*Func_eta(VSM_coef, p-1, gam_1, gam_2)^(-2) 
                             - 8 *gam_1 * gam_2 * VSM_coef[p]^(-6)*Func_eta(VSM_coef, p-1, gam_1, gam_2)^(-5))
  b4 <- -2 * gam_2 * (4 *Func_eta(VSM_coef, p, gam_1, gam_2)^(-5) * (VSM_coef[p] + 4*gam_1 *gam_2 * VSM_coef[p]^(-3) )^2 
                      + Func_eta(VSM_coef, p, gam_1, gam_2)^(-2) * (1+12*gam_1*gam_2 *VSM_coef[p]^(-4)))
  c4 <- -2 * gam_2 * Func_eta(VSM_coef, p, gam_1, gam_2)^(-2) * (VSM_coef[p] - 4 *gam_1*gam_2 * VSM_coef[p]^(-3))
  d4 <- 4 * gam_1 *gam_2^2 * (-3 * VSM_coef[p]^(-4) * Func_eta(VSM_coef, p+1, gam_1, gam_2)^(-2) 
                              -8 * gam_1 * gam_2 *  VSM_coef[p]^(-6) * Func_eta(VSM_coef, p+1, gam_1, gam_2)^(-5))
  e4 <- 4 * gam_1 *gam_2^2 * VSM_coef[p]^(-3) * Func_eta(VSM_coef, p+1, gam_1, gam_2)^(-2)
  f4 <- a4
  g4 <- 4 *gam_1 *gam_2^2 * VSM_coef[p]^(-3) *Func_eta(VSM_coef, p-1, gam_1, gam_2)^(-2)
                      

  Value <- 
    { log_likelihood(reg_var, Basis_function, p, p)
      -(1/2)*(a4 * VSM_coef[p-1]^(2) + b4 * VSM_coef[p]^2 + 2*c4 * VSM_coef[p] 
            + 2 * c4 * VSM_coef[p] + 2 * lambda(VSM_coef, p, gam_1, gam_2) + d4 * lambda(VSM_coef, p+1, gam_1, gam_2)^2)
      -(gam_1/2)*(- 2 * ( d4 * (lambda(VSM_coef, p+2, gam_1, gam_2) - lambda(VSM_coef, p+1, gam_1, gam_2)) - e4^2 ) 
                - 2 * (f4 * (lambda(VSM_coef, p-2, gam_1, gam_2) - lambda(VSM_coef, p-1, gam_1, gam_2)) - g4 ^2)
                + 2 * (e4^2 + lambda(VSM_coef, p+1, gam_1, gam_2) * d4)
                - 2 * (d4 * lambda(VSM_coef, p, gam_1, gam_2) + 2 * e4 * c4 + lambda(VSM_coef, p+1, gam_1, gam_2) * b4)
                + 4 * (c4^2 + lambda(VSM_coef, p, gam_1, gam_2) * b4)
                - 2 * (b4 * lambda(VSM_coef, p-1, gam_1, gam_2) + 2 * c4 * g4 + lambda(VSM_coef, p, gam_1, gam_2) * a4) 
                + 2 * (g4^2 + lambda(VSM_coef, p-1, gam_1, gam_2) * a4))
      +(gam_2/2) * (a4*lambda(VSM_coef, p-1, gam_1, gam_2)^(-1) - g4^2 * lambda(VSM_coef, p-1, gam_1, gam_2)^(-2) + b4 * lambda(VSM_coef, p, gam_1, gam_2)^(-1) 
                  - c4^2 * lambda(VSM_coef, p, gam_1, gam_2)^(-2) + d4 *lambda(VSM_coef, p+1, gam_1, gam_2)^(-1) - e4^2 * lambda(VSM_coef, p+1, gam_1, gam_2)^(-2) )}
  
  return(Value)
}

#complete