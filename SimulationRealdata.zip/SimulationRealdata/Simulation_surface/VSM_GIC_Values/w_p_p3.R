#lをw_pとw_{p-3}で微分したもの

w_p_p_minus_3 <- function(VSM_coef, reg_var, Basis_function, gam_1, gam_2, p){
  Value <- {log_likelihood(reg_var, Basis_function, p, p-3)
    +gam_1 * (4 * gam_1 * gam_2 ^2 * VSM_coef[p]^(-3) * Func_eta(VSM_coef, p-1, gam_1, gam_2)^(-2))*( 4 * gam_1 * gam_2^2 * VSM_coef[p-3]^(-3) * Func_eta(VSM_coef, p-2, gam_1, gam_2)^(-2) )}

  return(Value)
}

#lをw_pとw_{p+3}で微分したもの

w_p_p_plus_3 <- function(VSM_coef, reg_var, Basis_function, gam_1, gam_2, p){
  Value <- {log_likelihood(reg_var, Basis_function, p, p+3)
   + gam_1 * (4 * gam_1 * gam_2 ^2 * VSM_coef[p]^(-3) * Func_eta(VSM_coef, p+1, gam_1, gam_2)^(-2) )*( 4 * gam_1 * gam_2^2 * VSM_coef[p+3]^(-3) * Func_eta(VSM_coef, p+2, gam_1, gam_2)^(-2) )}

  return(Value)
}



#complete