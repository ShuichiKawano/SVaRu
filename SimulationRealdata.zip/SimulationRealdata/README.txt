There are four folders: Simulation_curve1, Simulation_curve2, Simulation_surface, and RealDataAnalysis. The explanation of these folders is below.

Simulation_curve1 : The folder includes source codes that perform curve fitting for the function (11) in Section 4.1.
Simulation_curve2 : The folder includes source codes that perform curve fitting for the function (12) in Section 4.1.
Simulation_surface : The folder includes source codes that perform surface fitting for the function (14) in Section 4.2.
RealDataAnalysis : The folder includes source codes that perform real data analysis in Section 5.

In all folders, run the source code "main.R". Then, you can obtain results. For the code "main.R" in Simulation_curve1, Simulation_curve2, and Simulation_surface, the variable "monte_num" represents the number of simulations,  "n_sample" the sample size, and "true_stan_dev" the standard deviation of errors. 
