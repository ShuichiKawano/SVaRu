VSM_main_function <- function(n_monte, n_sample, start_data, end_data, true_stan_dev
                              , true_function, basis_num_vec, width_para, start_smooth
                              , end_smooth, n_smooth, n_gam, start_gam1
                              , end_gam1, start_gam2, end_gam2) {

  source("sample_generation.R")
  source("True_Func.R")
  source("VSM_GIC.R")
  source("Gauss_Kernel.R")
  set.seed(0)
  
  #####-----setting the parameters start-----#
  MSE_ridge_vec <- 0 * seq(1,1,length = n_monte)
  MSE_lasso_vec <- 0 * seq(1,1,length = n_monte)
  MSE_VSM_vec <- 0 * seq(1,1,length = n_monte)
  MSE_adalasso_vec <- 0 * seq(1,1,length = n_monte)
  MSE_locfit_vec <- 0 * seq(1,1,length = n_monte)
  
  smooth_vec <- seq(start_smooth, end_smooth, length = n_smooth)
  gam_1_vec <- seq(start_gam1, end_gam1, length = n_gam)
  gam_2_vec <- seq(start_gam2, end_gam2, length = n_gam)
  #####-----setting the parameters end-----#
  
  #####-----Monte Carlo simulation start-----#
  for (q in 1: n_monte){
    sample <- sample_generation(n_sample, start_data, end_data, true_func_num, true_stan_dev)
    exp_data <- sample[[1]]
    true_curve <- sample[[2]]
    res_data <- sample[[3]]
    #VSM-start
    opt_paras_VSM <- VSM_GIC(exp_data, res_data, basis_num_vec, smooth_vec, width_para, gam_1_vec, gam_2_vec)
    opt_n_basis <- opt_paras_VSM[[1]]
    opt_gam_1 <- opt_paras_VSM[[2]]
    opt_gam_2 <- opt_paras_VSM[[3]]
    VSM_opt_coef <- opt_paras_VSM[[4]]
    VSM_reg_var <- opt_paras_VSM[[5]]
    VSM_opt_lam <- opt_paras_VSM[[6]] 
    #VSM-end
    #
    #basis function VSM, ridge, lasso and adalasso
    width_para_vec <- width_para * seq(1, 1, length = opt_n_basis)
    basis_mean_point <- seq(start_data, end_data,length = opt_n_basis)
    Basis_function <- Gauss_Kernel(exp_data, basis_mean_point, width_para_vec)
    
    #VSM
    est_VSM <- Basis_function %*% VSM_opt_coef 
    #ridge
    ridge_GIC_result <- ridge_GIC(Basis_function, res_data, smooth_vec)
    est_ridge <- ridge_GIC_result[[1]]
    opt_smooth_ridge <- ridge_GIC_result[[2]]
    #lasso
    CV_Lasso <- cv.glmnet(Basis_function, res_data, offset = NULL, alpha = 1, nlambda = 100, standardize = FALSE)
    Lasso_coef <- coef(CV_Lasso)
    Lasso_coef <- as.vector(Lasso_coef)
    Lasso_int <- Lasso_coef[1]
    Lasso_coef <- Lasso_coef[2:length(Lasso_coef)]
    est_lasso <- Basis_function %*% Lasso_coef + Lasso_int
    
    CV_Adalasso <- adalasso(Basis_function, res_data, k=5, use.Gram = FALSE, both = TRUE)
    Adalasso_int <- CV_Adalasso$intercept.adalasso
    Adalasso_coef <- CV_Adalasso$coefficients.adalasso
    Adalasso_coef <- as.vector(Adalasso_coef)
    Adalasso_lambda <- CV_Adalasso$cv.adalasso
    est_adalasso <- Basis_function%*%Adalasso_coef + Adalasso_int
    
    alpha_candidate <- seq(0.01, 5.0, by=0.01)
    AIC <- summary(aicplot(res_data~exp_data, alpha=alpha_candidate))[ ,2]
    fit <- locfit(res_data~exp_data, alpha=alpha_candidate[which.min(AIC)])
    result_locfit <- predict(fit, exp_data)

    dev.set(1)
    plot(exp_data, est_VSM, xlim=c(start_data,end_data), ylim=c(min(res_data)-0.2,max(res_data)+0.2),
         type = "l", xlab="", ylab="", lty = 1, lwd=2)
    par(new=T)
    plot(exp_data, res_data, xlim=c(start_data,end_data), ylim=c(min(res_data)-0.2,max(res_data)+0.2),
         xlab="", ylab="")
    par(new=T)
    plot(exp_data, true_curve, xlim=c(start_data,end_data), ylim=c(min(res_data)-0.2,max(res_data)+0.2),
         type = "l", xlab="", ylab="", lty = 2, lwd=2)
    panel.first=grid(8,8)
    dev.set(1)
    plot(exp_data, est_ridge, xlim=c(start_data,end_data), ylim=c(min(res_data)-0.2,max(res_data)+0.2),
         type = "l", xlab="", ylab="", lty = 1, lwd=2)
    par(new=T)
    plot(exp_data, res_data, xlim=c(start_data,end_data), ylim=c(min(res_data)-0.2,max(res_data)+0.2),
         xlab="", ylab="")
    par(new=T)
    plot(exp_data, true_curve, xlim=c(start_data,end_data), ylim=c(min(res_data)-0.2,max(res_data)+0.2),
         type = "l", xlab="", ylab="", lty = 2, lwd=2)
    panel.first=grid(8,8)
    dev.set(1)
    plot(exp_data, est_lasso, xlim=c(start_data,end_data), ylim=c(min(res_data)-0.2,max(res_data)+0.2),
         type = "l", xlab="", ylab="", lty = 1, lwd=2)
    par(new=T)
    plot(exp_data, res_data, xlim=c(start_data,end_data), ylim=c(min(res_data)-0.2,max(res_data)+0.2),
         xlab="", ylab="")
    par(new=T)
    plot(exp_data, true_curve, xlim=c(start_data,end_data), ylim=c(min(res_data)-0.2,max(res_data)+0.2),
         type = "l", xlab="", ylab="", lty = 2, lwd=2)
    panel.first=grid(8,8)
    dev.set(1)
    plot(exp_data, est_adalasso, xlim=c(start_data,end_data), ylim=c(min(res_data)-0.2,max(res_data)+0.2),
         type = "l", xlab="", ylab="", lty = 1, lwd=2)
    par(new=T)
    plot(exp_data, res_data, xlim=c(start_data,end_data), ylim=c(min(res_data)-0.2,max(res_data)+0.2),
         xlab="", ylab="")
    par(new=T)
    plot(exp_data, true_curve, xlim=c(start_data,end_data), ylim=c(min(res_data)-0.2,max(res_data)+0.2),
         type = "l", xlab="", ylab="", lty = 2, lwd=2)
    panel.first=grid(8,8)
    dev.set(1)
    plot(exp_data, result_locfit, xlim=c(start_data,end_data), ylim=c(min(res_data)-0.2,max(res_data)+0.2),
         type = "l", xlab="", ylab="", lty = 1, lwd=2)
    par(new=T)
    plot(exp_data, res_data, xlim=c(start_data,end_data), ylim=c(min(res_data)-0.2,max(res_data)+0.2),
         xlab="", ylab="")
    par(new=T)
    plot(exp_data, true_curve, xlim=c(start_data,end_data), ylim=c(min(res_data)-0.2,max(res_data)+0.2),
         type = "l", xlab="", ylab="", lty = 2, lwd=2)
    panel.first=grid(8,8)

    #MSE
    MSE_ridge <- 0
    MSE_lasso <- 0
    MSE_VSM <- 0
    MSE_adalasso <- 0
    for (k in 1:n_sample){
      MSE_ridge = (1/n_sample) * (true_curve[k] - est_ridge[k])^(2) + MSE_ridge
      MSE_lasso = (1/n_sample) * (true_curve[k] - est_lasso[k])^(2) + MSE_lasso
      MSE_adalasso = (1/n_sample) * (true_curve[k] - est_adalasso[k])^(2) + MSE_adalasso
      MSE_VSM = (1/n_sample) * (true_curve[k] - est_VSM[k])^(2) + MSE_VSM
    }
    MSE_ridge_vec[q] = MSE_ridge
    MSE_lasso_vec[q] = MSE_lasso
    MSE_VSM_vec[q] = MSE_VSM
    MSE_adalasso_vec[q] = MSE_adalasso
    MSE_locfit_vec[q] = mean( ( result_locfit - true_curve )^2 )
  }
  
  return(list(MSE_VSM_vec, MSE_ridge_vec, MSE_lasso_vec, MSE_adalasso_vec, MSE_locfit_vec))
}
